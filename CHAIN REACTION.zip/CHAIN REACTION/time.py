import audioread
sound = audioread.audio_open("sounds/explode_sound1.mp3")
print(sound.duration)